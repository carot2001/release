package OOP.cuoiky;


/**
 * @author hieulm
 *
 */
public class KySu extends CanBo{
	private String major;
	
	public KySu(String name, int age, String sex, String address, String major) {
		super(name, age, sex, address);
		this.setMajor(major);
		
	}

	public void display() {
		super.display();
		System.out.println("Nganh dao tao: " + getMajor());
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}
}
