package OOP.cuoiky;

import java.util.ArrayList;
import java.util.List;

public class QLCB {
	private List<CanBo> canBoList; 
	public QLCB() {
		canBoList = new ArrayList<>();
	}
	
	public void addElement(CanBo canBo) {
		canBoList.add(canBo);
	}
	public void showElement() {
		for(CanBo canBo : canBoList) {
			System.out.println("Ten: " + canBo.getName());
			System.out.println("Tuoi: " + canBo.getAge());
			System.out.println("Gioi tinh: " + canBo.getSex());
			System.out.println("Dia chi: " +canBo.getAddress());
			
			if (canBo instanceof CongNhan) {
				CongNhan congNhan = (CongNhan) canBo;
				System.out.println("Bac: " + congNhan.getGrade());
			} else if (canBo instanceof KySu) {
				KySu kySu = (KySu) canBo;
				System.out.println("Nganh dao tao: " + kySu.getMajor());
			} else if (canBo instanceof NhanVien) {
				NhanVien nhanVien = (NhanVien) canBo;
				System.out.println("Cong Viec: " + nhanVien.getJob());
			}

		}
	}
	
}
