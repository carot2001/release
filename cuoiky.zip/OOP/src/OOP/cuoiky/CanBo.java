package OOP.cuoiky;

/**
 * @author hieulm
 *
 */
public class CanBo {
	private String name;
	private String address;
	private String sex;
	private int age;
	
	public CanBo(String name, int age, String sex, String address) {
		this.setName(name);
		this.setAge(age);
		this.setSex(sex);
		this.setAddress(address);
		// TODO Auto-generated constructor stub
	}
	public void display() {
		System.out.println("Ho Ten Can Bo: " + getName());
		System.out.println("Tuoi: " + getAge());
		System.out.println("Gioi Tinh: " + getSex());
		System.out.println("Dia Chi: " + getAddress());
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
