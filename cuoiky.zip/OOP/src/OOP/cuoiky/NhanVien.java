package OOP.cuoiky;

public class NhanVien extends CanBo{
	private String job;
	
	public NhanVien(String name, int age, String sex, String address, String job) {
		super(name, age, sex, address);
		this.job = job;
		// TODO Auto-generated constructor stub
	}
	public void display() {
		super.display();
		System.out.println("Cong viec: " + getJob());
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	
}
