package OOP.cuoiky;

public class CongNhan extends CanBo {
	private int grade;
	
	public CongNhan(String name, int age, String sex, String address, int grade) {
		super(name, age, sex, address);
		this.grade = grade;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		if(grade >= 1 && grade <= 10) {
			this.grade = grade;			
		}
		else {
			System.out.println("Bac phai tu 1 -> 10. Vui long nhap lai");
		}
	}
	public void display() {
		super.display();
		System.out.println("Bac: " + grade);
	}
}
